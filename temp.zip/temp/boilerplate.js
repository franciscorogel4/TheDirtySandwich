var boilerplate = boilerplate  || {  
  /*
  * Here is where we store the id of a running animation.
  * Without this, we can't dynamically cancel an animation
  */
  runningAnimationId: -1,
  
  /**
  * Get the WebGL 3D context. This wraps browser specific code to make 
  * getting the context easier.
  *
  * @param canvasId The ID representing the html canvas
  */
  getWebGLContext: function(canvasId){

    //retrieve the canvase element
    var canvas = document.getElementById(canvasId);
    if(!canvas){
      console.log("Failed to retrieve the <anvas> element");
    }

    var gl = canvas.getContext("webgl") || canvas.getContext("experimental-webgl");
    if(!gl){
   
      console.log("Failed to get the rendering contect for WebGL");
    }
 
    return gl;
  },
  
/**
  * Load a file asynchronously, this is done using the "old school" XMLHttpRequest 
  * object. This is the way AJAX calls where originally written, the reason I am using 
  * this here as opposed to something like jQuery.ajax is for simplicity. There is 
  * no need to include a third-party library for this lesson.
  *
  * @param url A relative url for the resource to load
  * @param callback A function to be executed upon completion. The signature is as follows: 
  *       @param responseText - The text retrieved from the server
  *       @param xhttp - the actual xmlhttp request object (check this for errors, etc.)
  */
  loadResourceAsync: function (url, callback){
    var xhttp;

    var bp = boilerplate;
  
    if (window.XMLHttpRequest) {
        xhttp = new XMLHttpRequest();
    } else {
      // code for IE6, IE5
      xhttp = new ActiveXObject("Microsoft.XMLHTTP");
    }

    xhttp.onreadystatechange = function() {
      if (xhttp.readyState == 4){
        if(xhttp.status != 200) {
          console.log("loadFileAsync Error: " + xhttp.statusText);  
        }
        
        callback(xhttp.responseText, xhttp);
      }  
    };

    xhttp.open("GET", url, true);
    xhttp.send();
  },

  loadShaderFiles: function(callback, vertexURL, fragUrl){

    var vUrl = "shaders/shader.vert";
    var fUrl =  "shaders/shader.frag";
   
    if(vertexURL)
    {
      vUrl = vertexURL;
    }  

    if(fragUrl)
    {
      fUrl = fragUrl;
    }  
    
    var bp = boilerplate;
    //"shaders/shader.vert"
    //If there is a running animation, stop it
    if(bp.runningAnimationId > 0){
      cancelAnimationFrame(bp.runningAnimationId);
    }
    
    //Load the Vertex Shader asynchronously
    bp.loadResourceAsync(vUrl, function(data){
      VSHADER_SOURCE = data;
    
      //Load the Fragment Shader asynchronously
      bp.loadResourceAsync(fUrl, function(data){
        FSHADER_SOURCE = data;
        
        if(window.shadersLoadedEvent){ //Let everyone know that the shaders are loaded
          document.getElementsByTagName("body")[0].dispatchEvent(window.shadersLoadedEvent);
        }
      

        if(callback){
          callback();
        }
      });
    });
  },

  /**
   * Create the linked program object
   * @param gl GL context
   * @param vshader a vertex shader program (string)
   * @param fshader a fragment shader program (string)
   * @return created program object, or null if the creation has failed
   */
  createProgram: function(gl, vshader, fshader) {
    // Create shader object
    bp : boilerplate;
    var vertexShader = bp.loadShader(gl, gl.VERTEX_SHADER, vshader);
    var fragmentShader = bp.loadShader(gl, gl.FRAGMENT_SHADER, fshader);

    if (!vertexShader || !fragmentShader) {
      console.log("Error creating program. Vertex Shader or Fragment Shader is undefined");
      return false;
    }

    // Create a program object
    var program = gl.createProgram();
    if (!program) {
      console.log("Error creating program. Program is undefined");
      return false;
    }

    // Attach the shader objects
    gl.attachShader(program, vertexShader);
    gl.attachShader(program, fragmentShader);

    // Link the program object
    gl.linkProgram(program);

    // Check the result of linking
    var linked = gl.getProgramParameter(program, gl.LINK_STATUS);
    if (!linked) {
      var error = gl.getProgramInfoLog(program);
      console.log('Failed to link program: ' + error);
      gl.deleteProgram(program);
      gl.deleteShader(fragmentShader);
      gl.deleteShader(vertexShader);

      return false;
    }

    gl.useProgram(program);
    gl.program = program;

    return true;
  },

  /**
  * Create a shader object
  * @param gl GL context
  * @param type the type of the shader object to be created
  * @param source shader program (string)
  * @return created shader object, or null if the creation has failed.
  */
  loadShader: function(gl, type, source) {
    // Create shader object

    var shader = gl.createShader(type);
    if (shader == null) {
      console.log('unable to create shader');
      return null;
    }

    // Set the shader program
    gl.shaderSource(shader, source);

    // Compile the shader
    gl.compileShader(shader);

    // Check the result of compilation
    var compiled = gl.getShaderParameter(shader, gl.COMPILE_STATUS);
    if (!compiled) {
      var error = gl.getShaderInfoLog(shader);
      console.log('Failed to compile shader: ' + error);
      gl.deleteShader(shader);
      return null;
    }

    return shader;
  },

  /**
  * Determine if both variables are defeined
  * @param one Any variable you wish to check is defined
  * @param two Any variable you wish to check is defined
  * @return True if both variables are defined, otherwise false.
  */
  areDefined: function(one, two){
    if(one == undefined || two == undefined){
      return false;
    }

    return true;
  }    
};