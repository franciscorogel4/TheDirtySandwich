var VSHADER_SOURCE = null;
var FSHADER_SOURCE = null;
var bp = bp || boilerplate;//Our reference to the Boilerplate code.

//We will use these vertices to draw shapes in mutliple locations
//on the canvas by translating the vertices with a Uniform variable.
var vertices = new Float32Array([ 
  -0.9, 0.9,   //Vertex 1, 
  -0.8, 0.7,   //Vertex 2
  -0.7, 0.9,   //Vertex 3
  -0.6, 0.7,   //Vertex 4
  -0.5, 0.9,   //Vertex 5
  -0.4, 0.7,   //Vertex 6
]); 

function init(){
  bp.loadShaderFiles(run, "shaders/sam.vert", "shaders/sam.frag"); //Load the Vertex Shaders asynchronously
}

//Run is called automatically after the shader files have been
//successfully asynchronously loaded.
function run(){
  //Create the program
  var gl = bp.getWebGLContext("target");
  bp.createProgram(gl, VSHADER_SOURCE, FSHADER_SOURCE);

  gl.clear(gl.COLOR_BUFFER_BIT);  // Clear <canvas>

  var total = initVertexBuffers(gl);

  //grab the Uniform variable from the GL Program
  var u_Translation = gl.getUniformLocation(gl.program, 'u_Translation');

  //Draw the shape WITHOUT trabslation the first time
  gl.drawArrays(gl.POINTS, 0, 6); //Draw the POINTS without translation

  //Now, update the "Translation" Uniform variable prior to drawing
  gl.uniform4f(u_Translation, 0.6, 0.0, 0.0, 0.0); //Translate each vertex to the right (x == 0.6)
  gl.drawArrays(gl.LINES, 0, 6); //Draw as LINES
  
  //Update the "Translation" Uniform variable prior to drawing
  gl.uniform4f(u_Translation, 0.0, -0.6, 0.0, 0.0); //Translate each vertex down (y == -0.6)
  gl.drawArrays(gl.LINE_STRIP, 0, 6); //Draw a LINE_STRIP

  //Update the "Translation" Uniform variable prior to drawing
  gl.uniform4f(u_Translation, 0.6, -0.6, 0.0, 0.0);//Translate each vertex down and to the right (x == 0.6, y = -0.6)
  gl.drawArrays(gl.LINE_LOOP, 0, 6); //Draw as a LINE_LOOP
  
  //Update the "Translation" Uniform variable prior to drawing
  gl.uniform4f(u_Translation, 0.0, -1.2, 0.0, 0.0); //Translate each vertex down further (y == -1.2)
  gl.drawArrays(gl.TRIANGLES, 0, 6); //Draw as TRIANGLES
  
  //Update the "Translation" Uniform variable prior to drawing
  gl.uniform4f(u_Translation, 0.6, -1.2, 0.0, 0.0); //Translate each vertex down and to the right (x == 0.6, y = -1.2)
  gl.drawArrays(gl.TRIANGLE_STRIP, 0, 6); //Draw as a TRIANGLE_STRIP
}   

function initVertexBuffers(gl){
console.log("initVertexBuffers")
  //create the buffer object
  var buffer = gl.createBuffer();
  if(!buffer){
    console.log('Failed to create the buffer object');
    
    return -1;
  }

  //bind the buffer object to target. The keyword ARRAY_BUFFER 
  //specifies that the buffer contains vertex data
  gl.bindBuffer(gl.ARRAY_BUFFER, buffer);

  //Now that we have the buffer, let's write some data into it. This writes the 
  //data in the second parameter (vertices) into the ARRAY_BUFFER. The third 
  //parameter can be STATIC_DRAW, STREAM_DRAW, or DYNAMIC_DRAW. STATIC_DRAW is 
  //used if the buffer object data will be specified once and used many times 
  //to draw shapes.
  gl.bufferData(gl.ARRAY_BUFFER, vertices, gl.STATIC_DRAW);

  // Get the storage location of a_Position
  var a_Position = gl.getAttribLocation(gl.program, 'a_Position');
  
  // Assign the buffer object to a_Postiion variable
  gl.vertexAttribPointer(a_Position, 2, gl.FLOAT, false, 0, 0);

  //Enable the assignment to a_Position
  gl.enableVertexAttribArray(a_Position);

  var numberOfVertices = Math.floor(vertices.length / 2); 
console.log("numberOfVertices: " + numberOfVertices)

  return numberOfVertices;
}